<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Insertar Pacientes</title>
    </head>
    <body>
        <h1>Insertar Pacientes</h1>
        <form method="POST">
            <input type="text" name="nombre_paciente" placeholder="Nombre del paciente">
            <br>
            <input type="text" name="importe_mensual" placeholder="Importe mensual">
            <br>
            <button type="submit" title="insertar_pacientes" name="insertar_pacientes">Insertar Datos</button>
            <button type="submit" title="ver_pacientes" name="ver_pacientes">Ver Pacientes</button>
            <button type="submit" title="cerrar_sesion" name="cerrar_sesion">Cerrar Sesión</button>
        </form>

        <?php
        if (isset($_POST["insertar_pacientes"])) {

            // Conectarse a la base de datos
            $user = "root";
            $dsn = "mysql:host=localhost;dbname=bdpacientes";
            $dbh = new PDO($dsn, $user);

            // Obtener el siguiente código de paciente disponible
            $stmt = $dbh->prepare("SELECT MAX(codigo_paciente) as max_codigo FROM pacientes");
            $stmt->execute();
            $max_codigo = $stmt->fetch(PDO::FETCH_OBJ)->max_codigo;
            $codigo_paciente = $max_codigo + 1;

            // Obtener el nombre del paciente y el importe del seguro
            $nombre_paciente = $_POST["nombre_paciente"];
            $importe_mensual = $_POST["importe_mensual"];

            // Obtener el usuario que ha registrado el paciente 
            session_start();
            $usuario = $_SESSION["usuario"];

            $dbh->beginTransaction();
            // Insertar el nuevo paciente en la base de datos
            $stmt = $dbh->prepare("INSERT INTO pacientes (codigo_paciente, nombre_paciente, importe_seguro, usuario) VALUES (:codigo_paciente, :nombre_paciente, :importe_mensual, :usuario)");
            $stmt->bindParam(":codigo_paciente", $codigo_paciente);
            $stmt->bindParam(":nombre_paciente", $nombre_paciente);
            $stmt->bindParam(":importe_mensual", $importe_mensual);
            $stmt->bindParam(":usuario", $usuario);
            $stmt->execute();
            if ($dbh->commit()) {
                 echo "Paciente insertado correctamente";
            } else {
                echo "La transacción falló";
                $dbh->rollBack();
            }
           
        }


        if (isset($_POST["cerrar_sesion"])) {
            header("Location: index.php");
            exit();
            session_destroy();
        }

        if (isset($_POST["ver_pacientes"])) {
            header("Location: pacientes.php");
            exit();
        }
        ?>
    </body>
</html>
