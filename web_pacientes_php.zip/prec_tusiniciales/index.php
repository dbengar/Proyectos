<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Inicio</title>
    </head>
    <body>
        <h1>Bienvenido</h1>
        <form method="post">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>
            <br>
            <input type="submit" name="ver_pacientes" value="Ver Pacientes">
            <input type="submit" name="insertar_paciente" value="Insertar Paciente">
        </form>
        <?php
        session_start();

        if (isset($_POST['nombre'])) {
            $_SESSION['usuario'] = $_POST['nombre'];

            if (isset($_POST['ver_pacientes'])) {
                header('Location: pacientes.php');
                exit();
            } 
            if (isset($_POST['insertar_paciente'])) {
                header('Location: insertar.php');
                exit();
            }
        }
        ?>
    </body>
</html>
