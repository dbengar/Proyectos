<html>
    <head>
        <meta charset="UTF-8">
        <title>Lista Pacientes</title>
    </head>
    <body>
        <form method="POST">
            <table>
                <tr>
                    <th>Nombre</th>
                    <th>Importe Seguro</th>
                </tr>

                <?php
                //Conectamos con la base de datos
                $user = "root";
                $dsn = "mysql:host=localhost;dbname=bdpacientes";
                $dbh = new PDO($dsn, $user);

                //Consulta para obtener los pacientes de la base de datos
                $sql = "SELECT nombre_paciente, importe_seguro FROM pacientes";
                $stmt = $dbh->prepare($sql);

                $stmt->execute();

                //Verificamos si hay registros en la base de datos
                if ($stmt->rowCount() > 0) {
                    //Se muestran los pacientes
                    while ($mostrar = $stmt->fetch(PDO::FETCH_OBJ)) {
                        ?>

                        <tr>
                            <td><?php echo $mostrar->nombre_paciente ?></td>
                            <td><?php echo $mostrar->importe_seguro . "$" ?></td>
                        </tr>

                        <?php
                    }
                } else {
                    echo "No se encontraron pacientes en la base de datos.";
                }
                ?>

            </table>
            <?php echo "<button type=\"submit\"  title=\"insertar_paciente\" name=\"insertar_paciente\">Insertar Pacientes</button>" ?>
            <?php echo "<button type=\"submit\"  title=\"cerrar_sesion\" name=\"cerrar_sesion\">Cerrar sesión</button>" ?>
        </form>
        <?php
        //Cerramos la sesiom
        if (isset($_POST["cerrar_sesion"])) {
            header("Location: index.php");
            exit();
            session_destroy();
        }
        
        //Accedemos a la pantalla de insertar
        if (isset($_POST["insertar_paciente"])) {
            header("Location: insertar.php");
            exit();
        }
        ?>
    </body>
</html>